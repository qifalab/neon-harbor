# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: rooms.spec.js >> two independent browsers share a room, rendered walking peers, chat and disconnect
- Location: tests/multiplayer-browser/rooms.spec.js:18:1

# Error details

```
TimeoutError: page.waitForFunction: Timeout 30000ms exceeded.
```

# Test source

```ts
  1   | import { test,expect } from '@playwright/test';
  2   | import { writeFile } from 'node:fs/promises';
  3   | import { snapshot } from '../e2e/helpers/walking.js';
  4   | import { chooseStorey } from '../e2e/helpers/occupied.js';
  5   | async function boot(page){
  6   |   await page.addInitScript(()=>localStorage.setItem('neon-harbor.settings.v1',JSON.stringify({quality:'low',volume:0,dayCycle:false,hour:16.5})));
  7   |   await page.goto('/');await expect(page.locator('#start')).toBeEnabled({timeout:90000});
  8   |   // The short welcome screen must scroll through normal keyboard focus.
  9   |   // Reaching this button also proves it is not clipped by the fixed document.
  10  |   for(let tab=0;tab<12&&await page.evaluate(()=>document.activeElement?.id)!=='welcome-multiplayer';tab++)await page.keyboard.press('Tab');
  11  |   await expect(page.locator('#welcome-multiplayer')).toBeFocused();
  12  |   await expect(page.locator('#welcome-multiplayer')).toBeInViewport({ratio:1});
  13  | }
  14  | async function join(page,name,code=''){
  15  |   await page.locator('#welcome-multiplayer').click();await page.locator('#room-name').fill(name);await page.locator('#room-code').fill(code);await page.locator('#room-join').click();
  16  |   await expect(page.locator('#welcome')).toBeHidden();await expect.poll(()=>page.evaluate(()=>window.__NEON__.snapshot().multiplayer.status)).toBe('connected');
  17  | }
  18  | test('two independent browsers share a room, rendered walking peers, chat and disconnect',async({playwright},testInfo)=>{
  19  |   // Separate browser processes model two machines and avoid sharing one
  20  |   // software GPU command queue between the clients on hosted CI runners.
  21  |   const clients=await Promise.all([playwright.chromium.launch(testInfo.project.use.launchOptions),playwright.chromium.launch(testInfo.project.use.launchOptions)]);
  22  |   try{
  23  |     const first=await clients[0].newContext({baseURL:testInfo.project.use.baseURL,viewport:{width:640,height:400}}),second=await clients[1].newContext({baseURL:testInfo.project.use.baseURL,viewport:{width:640,height:400}}),a=await first.newPage(),b=await second.newPage(),errors=[];
  24  |     for(const page of [a,b])page.on('pageerror',e=>errors.push(e.message));
  25  |     await boot(a);
  26  |     const welcomeEvidence=testInfo.outputPath('welcome-short-window-multiplayer.png');
  27  |     await a.screenshot({path:welcomeEvidence});await testInfo.attach('welcome-short-window-multiplayer',{path:welcomeEvidence,contentType:'image/png'});
  28  |     await join(a,'海风');const code=await a.evaluate(()=>window.__NEON__.snapshot().multiplayer.code);
  29  |     await a.locator('#multiplayer').click();
  30  |     await boot(b);await join(b,'榕荫',code);await a.locator('#resume').click();
  31  |     await expect.poll(()=>a.evaluate(()=>window.__NEON__.snapshot().multiplayer.players.length)).toBe(2);
  32  |     await expect.poll(()=>b.evaluate(()=>window.__NEON__.snapshot().multiplayer.meshes.filter(p=>p.visible).length)).toBe(1);
  33  |     const start=await a.evaluate(()=>window.__NEON__.snapshot().position);
  34  |     await a.locator('#game').focus();await a.keyboard.down('KeyW');
  35  |     await a.waitForFunction(({start})=>Math.hypot(window.__NEON__.snapshot().position.x-start.x,window.__NEON__.snapshot().position.z-start.z)>3,{start},{timeout:30000});await a.keyboard.up('KeyW');
  36  |     const target=await a.evaluate(()=>window.__NEON__.snapshot().position);
  37  |     await expect.poll(()=>b.evaluate(({target})=>{const mesh=window.__NEON__.snapshot().multiplayer.meshes[0];return mesh?Math.hypot(mesh.x-target.x,mesh.z-target.z):1000;},{target})).toBeLessThan(.6);
> 38  |     await a.keyboard.down('KeyW');await a.waitForFunction(()=>window.__NEON__.snapshot().cars.some(c=>c.id==='starter'&&Math.hypot(c.x-window.__NEON__.snapshot().position.x,c.z-window.__NEON__.snapshot().position.z)<5),null,{timeout:30000});await a.keyboard.up('KeyW');
      |                                           ^ TimeoutError: page.waitForFunction: Timeout 30000ms exceeded.
  39  |     await a.keyboard.press('KeyE');await expect.poll(()=>a.evaluate(()=>window.__NEON__.snapshot().inCar)).toBe('starter');
  40  |     const carStart=await a.evaluate(()=>window.__NEON__.snapshot().position);
  41  |     await a.keyboard.down('KeyW');await a.waitForFunction(({carStart})=>Math.hypot(window.__NEON__.snapshot().position.x-carStart.x,window.__NEON__.snapshot().position.z-carStart.z)>3,{carStart},{timeout:30000});await a.keyboard.up('KeyW');
  42  |     await a.keyboard.down('Space');await a.waitForFunction(()=>window.__NEON__.snapshot().speed<.5,null,{timeout:30000});await a.keyboard.up('Space');
  43  |     const carTarget=await a.evaluate(()=>window.__NEON__.snapshot().cars.find(c=>c.id==='starter'));
  44  |     await expect.poll(()=>b.evaluate(({carTarget})=>{const car=window.__NEON__.snapshot().cars.find(c=>c.id==='starter');return Math.hypot(car.x-carTarget.x,car.z-carTarget.z);},{carTarget})).toBeLessThan(1);
  45  |     await a.keyboard.press('KeyE');await expect.poll(()=>a.evaluate(()=>window.__NEON__.snapshot().inCar)).toBe(null);
  46  |     await a.locator('#multiplayer').click();await a.locator('#room-message').fill('一起去看海');await a.locator('#room-chat-form button').click();
  47  |     await b.locator('#multiplayer').click();await expect(b.locator('#room-chat')).toContainText('海风：一起去看海');
  48  |     await a.locator('#room-leave').click();await expect.poll(()=>b.evaluate(()=>window.__NEON__.snapshot().multiplayer.players.length)).toBe(1);
  49  |     await expect.poll(()=>b.evaluate(()=>window.__NEON__.snapshot().multiplayer.meshes.length)).toBe(0);
  50  |     expect(errors).toEqual([]);await first.close();await second.close();
  51  |   }finally{await Promise.all(clients.map(client=>client.close()));}
  52  | });
  53  | 
  54  | 
  55  | test('two browsers synchronize expanded east-bay addresses and elevator floors beyond the former 320 metre limit', async ({ playwright }, testInfo) => {
  56  |   test.setTimeout(600000);
  57  |   const clients = await Promise.all([
  58  |     playwright.chromium.launch(testInfo.project.use.launchOptions),
  59  |     playwright.chromium.launch(testInfo.project.use.launchOptions),
  60  |   ]);
  61  |   try {
  62  |     const options = { baseURL: testInfo.project.use.baseURL, viewport: { width: 640, height: 400 } };
  63  |     const first = await clients[0].newContext(options), second = await clients[1].newContext(options);
  64  |     const a = await first.newPage(), b = await second.newPage(), errors = [];
  65  |     for (const page of [a, b]) {
  66  |       page.on('pageerror', error => errors.push(error.message));
  67  |       page.on('response', response => {
  68  |         if (response.status() >= 400 && new URL(response.url()).pathname.startsWith('/api/'))
  69  |           errors.push(`HTTP ${response.status()}: ${new URL(response.url()).pathname}`);
  70  |       });
  71  |     }
  72  |     // Observe the second browser's actual server-sent events. This reads the
  73  |     // wire world identifier without changing the runtime or injecting poses.
  74  |     const network = await second.newCDPSession(b);
  75  |     await network.send('Network.enable');
  76  |     let received = null, trackedId = null;
  77  |     const receivedHeights = [];
  78  |     network.on('Network.eventSourceMessageReceived', event => {
  79  |       try {
  80  |         const packet = JSON.parse(event.data);
  81  |         if (Array.isArray(packet.players)) {
  82  |           received = packet;
  83  |           const visitor = packet.players.find(player => player.id === trackedId);
  84  |           if (visitor?.scene.startsWith('interior:east-012:')) receivedHeights.push(visitor.y);
  85  |         }
  86  |       }
  87  |       catch { errors.push('Invalid room event JSON'); }
  88  |     });
  89  |     await boot(a); await join(a, '东湾访客');
  90  |     const initial = await snapshot(a), code = initial.multiplayer.code, visitorId = initial.multiplayer.id;
  91  |     trackedId = visitorId;
  92  |     await a.locator('#multiplayer').click();
  93  |     await boot(b); await join(b, '海湾观察员', code);
  94  |     await b.locator('#multiplayer').click(); await a.locator('#resume').click();
  95  |     await expect.poll(() => received?.world).toBe('neon-harbor-v08');
  96  |     await expect.poll(() => received?.players.length).toBe(2);
  97  | 
  98  |     const assertRemotePose = async (position, scene) => {
  99  |       await expect.poll(() => {
  100 |         const peer = received?.players.find(player => player.id === visitorId);
  101 |         return peer?.scene === scene ? Math.hypot(peer.x - position.x, peer.y - position.y, peer.z - position.z) : Infinity;
  102 |       }).toBeLessThan(0.45);
  103 |       expect(received.world).toBe('neon-harbor-v08'); expect(received.code).toBe(code);
  104 |       await expect.poll(() => b.evaluate(({ visitorId, position, scene }) => {
  105 |         const peer = window.__NEON__.snapshot().multiplayer.players.find(player => player.id === visitorId);
  106 |         return peer?.scene === scene ? Math.hypot(peer.x - position.x, peer.y - position.y, peer.z - position.z) : Infinity;
  107 |       }, { visitorId, position, scene })).toBeLessThan(0.45);
  108 |       return received.players.find(player => player.id === visitorId);
  109 |     };
  110 |     const visit = async building => {
  111 |       await a.locator('#explore-city').click();
  112 |       await expect(a.locator('#atlas-results')).toBeVisible();
  113 |       await a.locator(`[data-visit-building="${building.id}"]`).click();
  114 |       await expect(a.locator('#panel')).not.toBeVisible({ timeout: 60000 });
  115 |       await expect(a.locator('#interaction')).toContainText(`进入 ${building.name}`);
  116 |       const state = await snapshot(a);
  117 |       expect(state.position.x).toBeCloseTo(building.entrance.x, 1);
  118 |       expect(state.position.z).toBeCloseTo(building.entrance.z, 1);
  119 |       await assertRemotePose(state.position, 'outdoor');
  120 |       return state;
  121 |     };
  122 | 
  123 |     const boundaryAddress = initial.city.buildings.find(building => building.id === 'east-037');
  124 |     expect(boundaryAddress).toBeTruthy();
  125 |     const boundary = await visit(boundaryAddress);
  126 |     expect(Math.max(Math.abs(boundary.position.x), Math.abs(boundary.position.z))).toBeGreaterThan(1450);
  127 |     // The atlas is the normal supported travel action. Entry and lift selection
  128 |     // below use the same interaction key, corridor walking and menu as players.
  129 |     const highAddress = initial.city.buildings.find(building => building.id === 'east-012');
  130 |     const highFloor = highAddress.floors.find(floor => floor.y > 325);
  131 |     expect(highFloor).toBeTruthy();
  132 |     await visit(highAddress);
  133 |     await a.keyboard.press('e');
  134 |     await expect.poll(async () => (await snapshot(a)).city.interior.buildingId).toBe(highAddress.id);
  135 |     const lobby = await snapshot(a);
  136 |     await assertRemotePose(lobby.position, `interior:${highAddress.id}:${highAddress.floors[0].id}`);
  137 |     await chooseStorey(a, highFloor.id);
  138 |     const upstairs = await snapshot(a);
```