# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: living-city.spec.js >> a resident rides to a furnished bedroom, walks through its doorway, and returns to the street
- Location: tests/e2e/living-city.spec.js:62:1

# Error details

```
Error: expect(received).toBeLessThan(expected)

Expected: < 5.2
Received:   5.5333333333336086
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic "霓港三维游戏画面" [active] [ref=e2]
  - main "游戏界面":
    - generic:
      - generic:
        - generic:
          - text: 霓港
          - generic: NEON HARBOR
        - generic:
          - text: 山茶公寓 · 室内
          - generic: 16:56 · 晴
      - generic:
        - button "切换步行与跟随视角" [ref=e3] [cursor=pointer]: 步行视角
        - button "打开多人房间" [ref=e4] [cursor=pointer]: 多人
        - button "暂停游戏" [ref=e5] [cursor=pointer]: Ⅱ
    - complementary:
      - generic: 室内探索
      - heading "山茶生活样板层" [level=2]
      - generic:
        - button "城市导览 ↗" [ref=e6] [cursor=pointer]
        - button "港湾日常 ↗" [ref=e7] [cursor=pointer]
        - generic: 4 m
    - generic:
      - generic: E
      - generic: 选择电梯楼层
  - status
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | import { walkAxis } from './helpers/walking.js';
  3   | 
  4   | // Player-facing menus, keys and walking provide every transition. Diagnostics
  5   | // are read-only: room entrances never become teleport targets in this suite.
  6   | test.use({ viewport: { width: 640, height: 400 } });
  7   | test.setTimeout(360000);
  8   | const snapshot = page => page.evaluate(() => window.__NEON__.snapshot());
  9   | 
  10  | async function boot(page, { low = false } = {}) {
  11  |   const errors = [], materials = new Set();
  12  |   page.on('pageerror', error => errors.push(error.message));
  13  |   page.on('console', message => { if (message.type() === 'error') errors.push(message.text()); });
  14  |   page.on('response', response => {
  15  |     if (response.status() >= 400) errors.push(`HTTP ${response.status()}: ${response.url()}`);
  16  |     if (response.ok() && /\/assets\/materials\/v04\/.+\.webp/.test(response.url())) materials.add(response.url().split('/').pop());
  17  |   });
  18  |   await page.goto('/');
  19  |   await expect(page.locator('#start')).toBeEnabled({ timeout: 90000 });
  20  |   if (low) {
  21  |     await page.locator('#welcome-settings').click();
  22  |     await page.locator('#quality').selectOption('low');
  23  |     await page.locator('#resume').click();
  24  |   }
  25  |   await page.locator('#start').click();
  26  |   await expect(page.locator('#game')).toBeFocused();
  27  |   return { errors, materials };
  28  | }
  29  | 
  30  | async function visit(page, kind, id) {
  31  |   await page.locator('#explore-city').click();
  32  |   await expect(page.locator('#atlas-results')).toBeVisible();
  33  |   await page.locator(`[data-visit-${kind}="${id}"]`).click();
  34  |   await expect(page.locator('#panel')).not.toBeVisible({ timeout: 45000 });
  35  |   await expect(page.locator('#game')).toBeFocused();
  36  | }
  37  | 
  38  | // The bedroom's real doorway needs the shared closed-loop endpoint correction.
  39  | // Preserve this suite's per-axis deadline while tightening its old 1.2 m margin
  40  | // to the helper's .75 m. Original long-aisle sprints end before the door approach.
  41  | const moveAxis = (page, axis, target, options = {}) => walkAxis(page, axis, target, { ...options, timeout: 90000 });
  42  | 
  43  | async function takeLift(page, floorId) {
  44  |   await page.keyboard.press('e');
  45  |   await expect(page.locator(`[data-floor-id="${floorId}"]`)).toBeEnabled();
  46  |   await page.locator(`[data-floor-id="${floorId}"]`).click();
  47  |   await expect.poll(async () => (await snapshot(page)).city.interior.moving).toBe(true);
  48  |   const moving = await snapshot(page);
  49  |   await expect.poll(async () => (await snapshot(page)).city.interior.moving, { timeout: 90000 }).toBe(false);
  50  |   const arrived = await snapshot(page);
  51  |   expect(arrived.city.interior.floorId).toBe(floorId);
  52  |   expect(arrived.city.interior.elevator.doorOpen).toBe(1);
> 53  |   expect(arrived.simulationTime - moving.simulationTime).toBeLessThan(moving.city.interior.elevator.duration + 3);
      |                                                          ^ Error: expect(received).toBeLessThan(expected)
  54  | }
  55  | 
  56  | async function capture(page, testInfo, name) {
  57  |   const path = testInfo.outputPath(`${name}.png`);
  58  |   await page.screenshot({ path, timeout: 90000 });
  59  |   await testInfo.attach(name, { path, contentType: 'image/png' });
  60  | }
  61  | 
  62  | test('a resident rides to a furnished bedroom, walks through its doorway, and returns to the street', async ({ page }, testInfo) => {
  63  |   const { errors } = await boot(page, { low: true });
  64  |   await visit(page, 'building', 'camellia-court');
  65  |   await page.keyboard.press('e');
  66  |   await expect.poll(async () => (await snapshot(page)).city.interior.buildingId).toBe('camellia-court');
  67  |   const entered = await snapshot(page), lobby = entered.city.interior;
  68  |   expect(lobby.floorId).toBe('lobby');
  69  |   await moveAxis(page, 'z', lobby.cabin.z, { sprint: true });
  70  |   await takeLift(page, 'gallery');
  71  |   const floor = (await snapshot(page)).city.interior;
  72  |   expect(floor.roomCount).toBe(4);
  73  |   const room = floor.rooms.find(room => room.type === 'bedroom');
  74  |   expect(room, 'the residential upper floor has an actual furnished bedroom').toBeTruthy();
  75  |   expect(room.name).toContain('卧');
  76  |   expect(room.enclosed).toBe(true);
  77  |   expect(room.width).toBeLessThanOrEqual(10);
  78  |   expect(room.depth).toBeLessThanOrEqual(10);
  79  |   expect(room.entrance).toBeTruthy();
  80  |   expect(room.arrival).toBeTruthy();
  81  |   // First align with the real door, then pass through it. This exposes a blocked
  82  |   // doorway even if the directory and furniture metadata are perfectly valid.
  83  |   await moveAxis(page, 'z', room.entrance.z, { sprint: true });
  84  |   await moveAxis(page, 'x', room.arrival.x);
  85  |   await moveAxis(page, 'z', room.arrival.z);
  86  |   const inside = await snapshot(page);
  87  |   expect(Math.abs(inside.position.x - room.x)).toBeLessThan(room.width / 2);
  88  |   expect(Math.abs(inside.position.z - room.z)).toBeLessThan(room.depth / 2);
  89  |   const targetFloor = inside.city.buildings.find(building => building.id === 'camellia-court').floors.find(floor => floor.id === 'gallery');
  90  |   expect(inside.position.y).toBeCloseTo(targetFloor.y, 1);
  91  |   expect(inside.city.interior.currentRoomId).toBe(room.id);
  92  |   expect(inside.city.interior.activeFloors).toBe(3);
  93  |   await capture(page, testInfo, 'living-city-camellia-bedroom');
  94  | 
  95  |   await moveAxis(page, 'z', room.entrance.z);
  96  |   await moveAxis(page, 'x', floor.entrance.x);
  97  |   await moveAxis(page, 'z', floor.cabin.z, { sprint: true });
  98  |   await takeLift(page, 'lobby');
  99  |   await moveAxis(page, 'z', lobby.entrance.z, { sprint: true });
  100 |   await page.keyboard.press('e');
  101 |   await expect.poll(async () => (await snapshot(page)).city.interior.buildingId).toBeNull();
  102 |   expect((await snapshot(page)).cars.length).toBeGreaterThan(0);
  103 |   expect(errors).toEqual([]);
  104 | });
  105 | 
  106 | test('default high quality loads crafted materials and exposes walk-in viewing and real infrastructure entrances', async ({ page }, testInfo) => {
  107 |   const { errors, materials } = await boot(page);
  108 |   expect((await snapshot(page)).settings.quality).toBe('high');
  109 |   await visit(page, 'building', 'tide-museum');
  110 |   await page.keyboard.press('e');
  111 |   await expect.poll(async () => (await snapshot(page)).city.interior.buildingId).toBe('tide-museum');
  112 |   const floor = (await snapshot(page)).city.interior;
  113 |   expect(floor.floorName).toContain('潮');
  114 |   expect(floor.rooms.some(room => room.type === 'maritime')).toBe(true);
  115 |   await page.keyboard.press('v');
  116 |   await expect(page.locator('#view-toggle')).toHaveAttribute('aria-pressed', 'true');
  117 |   // Switching view resets the rig immediately; the next actual render frame
  118 |   // supplies its new pose, so a transient null snapshot is expected here.
  119 |   await expect.poll(async () => (await snapshot(page)).camera?.boomLength).toBe(0);
  120 |   const eye = await snapshot(page);
  121 |   expect(eye.settings.firstPerson).toBe(true);
  122 |   expect(eye.camera.position.y - eye.position.y).toBeCloseTo(1.62, 1);
  123 |   expect(eye.renderer.calls).toBeGreaterThan(0);
  124 |   expect(eye.renderer.triangles).toBeGreaterThan(0);
  125 |   await expect.poll(() => materials.size).toBeGreaterThanOrEqual(3);
  126 |   for (const name of ['weathered-plaster.webp', 'aggregate-asphalt.webp', 'woven-linen.webp']) expect(materials.has(name), name).toBe(true);
  127 |   await capture(page, testInfo, 'living-city-museum-high-walking-view');
  128 |   // Both keyboard and visible button must leave the player in the same mode.
  129 |   await page.locator('#view-toggle').click();
  130 |   await expect(page.locator('#view-toggle')).toHaveAttribute('aria-pressed', 'false');
  131 |   expect((await snapshot(page)).settings.firstPerson).toBe(false);
  132 | 
  133 |   await page.locator('#explore-city').click();
  134 |   await expect(page.locator('[data-visit-landmark]')).toHaveCount(3);
  135 |   for (const id of ['west-link', 'east-link', 'victoria-freight']) await expect(page.locator(`[data-visit-landmark="${id}"]`)).toBeVisible();
  136 |   await page.locator('[data-visit-landmark="victoria-freight"]').click();
  137 |   await expect(page.locator('#panel')).not.toBeVisible({ timeout: 45000 });
  138 |   const outside = await snapshot(page);
  139 |   expect(outside.city.interior.buildingId).toBeNull();
  140 |   expect(outside.position.x).toBe(-620);
  141 |   expect(outside.position.z).toBe(-415);
  142 |   expect(outside.position.y).toBeCloseTo(0, 1);
  143 |   expect(outside.settings.quality).toBe('high');
  144 |   expect(errors).toEqual([]);
  145 | });
  146 | 
```