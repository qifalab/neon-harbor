# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: rooms.spec.js >> two independent browsers share a room, rendered walking peers, chat and disconnect
- Location: tests/multiplayer-browser/rooms.spec.js:76:1

# Error details

```
Error: tracing.start: Tracing has been already started
```

# Test source

```ts
  1   | import { test,expect } from '@playwright/test';
  2   | import { writeFile } from 'node:fs/promises';
  3   | import { snapshot } from '../e2e/helpers/walking.js';
  4   | import { chooseStorey } from '../e2e/helpers/occupied.js';
  5   | 
  6   | const motionEvidence = page => page.evaluate(() => {
  7   |   const state = window.__NEON__?.snapshot();
  8   |   if (!state) return { ready: false };
  9   |   const starter = state.cars.find(car => car.id === 'starter');
  10  |   return { position: state.position, simulationTime: state.simulationTime,
  11  |     teleportRevision: state.teleportRevision, inCar: state.inCar, speed: state.speed,
  12  |     starter, starterDistance: starter ? Math.hypot(starter.x - state.position.x, starter.z - state.position.z) : null,
  13  |     multiplayer: state.multiplayer, interior: state.city.interior,
  14  |     timing: state.timing, renderer: state.renderer };
  15  | });
  16  | 
  17  | /** Slow software rendering may advance only a few simulation seconds in a
  18  |  * minute. Bound wall time while recording actual progress; never alter poses,
  19  |  * clocks, input rules, or remote synchronization tolerances. */
  20  | async function holdUntil(page, key, predicate, argument, evidence, label) {
  21  |   const before = await motionEvidence(page), started = Date.now();
  22  |   let failure;
  23  |   await page.keyboard.down(key);
  24  |   try { await page.waitForFunction(predicate, argument, { polling: 'raf', timeout: 120000 }); }
  25  |   catch (error) { failure = error; }
  26  |   finally {
  27  |     try { await page.keyboard.up(key); }
  28  |     catch (error) { failure ||= error; }
  29  |   }
  30  |   let after;
  31  |   try { after = await motionEvidence(page); }
  32  |   catch (error) { after = { snapshotError: error.message }; failure ||= error; }
  33  |   const record = { label, key, wallMilliseconds: Date.now() - started, before, after };
  34  |   evidence.push(record);
  35  |   if (failure) {
  36  |     failure.message += `\nMultiplayer input diagnostics: ${JSON.stringify(record)}`;
  37  |     throw failure;
  38  |   }
  39  |   expect(after.teleportRevision, `${label} uses ordinary held input`).toBe(before.teleportRevision);
  40  | }
  41  | 
  42  | async function finishClients(clients, contexts, testInfo, failed, evidence) {
  43  |   const evidencePath = testInfo.outputPath('independent-client-progress.json');
  44  |   const final = [];
  45  |   if (failed) for (const [index, context] of contexts.entries()) for (const page of context.pages()) {
  46  |     try { final.push({ client: index, state: await motionEvidence(page) }); }
  47  |     catch (error) { final.push({ client: index, snapshotError: error.message }); }
  48  |   }
  49  |   await writeFile(evidencePath, JSON.stringify({ failed, phases: evidence, final }, null, 2));
  50  |   await testInfo.attach('independent-client-progress', { path: evidencePath, contentType: 'application/json' });
  51  |   for (const [index, context] of contexts.entries()) {
  52  |     try {
  53  |       if (failed) {
  54  |         const path = testInfo.outputPath(`independent-client-${index + 1}-trace.zip`);
  55  |         await context.tracing.stop({ path });
  56  |         await testInfo.attach(`independent-client-${index + 1}-trace`, { path, contentType: 'application/zip' });
  57  |       } else await context.tracing.stop();
  58  |     } catch (error) { console.error(`Client ${index + 1} trace: ${error.message}`); }
  59  |   }
  60  |   await Promise.all(clients.map(client => client.close()));
  61  | }
  62  | 
  63  | async function boot(page){
  64  |   await page.addInitScript(()=>localStorage.setItem('neon-harbor.settings.v1',JSON.stringify({quality:'low',volume:0,dayCycle:false,hour:16.5})));
  65  |   await page.goto('/');await expect(page.locator('#start')).toBeEnabled({timeout:90000});
  66  |   // The short welcome screen must scroll through normal keyboard focus.
  67  |   // Reaching this button also proves it is not clipped by the fixed document.
  68  |   for(let tab=0;tab<12&&await page.evaluate(()=>document.activeElement?.id)!=='welcome-multiplayer';tab++)await page.keyboard.press('Tab');
  69  |   await expect(page.locator('#welcome-multiplayer')).toBeFocused();
  70  |   await expect(page.locator('#welcome-multiplayer')).toBeInViewport({ratio:1});
  71  | }
  72  | async function join(page,name,code=''){
  73  |   await page.locator('#welcome-multiplayer').click();await page.locator('#room-name').fill(name);await page.locator('#room-code').fill(code);await page.locator('#room-join').click();
  74  |   await expect(page.locator('#welcome')).toBeHidden();await expect.poll(()=>page.evaluate(()=>window.__NEON__.snapshot().multiplayer.status)).toBe('connected');
  75  | }
  76  | test('two independent browsers share a room, rendered walking peers, chat and disconnect',async({playwright},testInfo)=>{
  77  |   test.setTimeout(600000);
  78  |   // Separate browser processes model two machines and avoid sharing one
  79  |   // software GPU command queue between the clients on hosted CI runners.
  80  |   const clients=await Promise.all([playwright.chromium.launch(testInfo.project.use.launchOptions),playwright.chromium.launch(testInfo.project.use.launchOptions)]);
  81  |   const contexts=[],evidence=[];let failed=true;
  82  |   try{
  83  |     const first=await clients[0].newContext({baseURL:testInfo.project.use.baseURL,viewport:{width:640,height:400}}),second=await clients[1].newContext({baseURL:testInfo.project.use.baseURL,viewport:{width:640,height:400}}),a=await first.newPage(),b=await second.newPage(),errors=[];
  84  |     contexts.push(first,second);
> 85  |     await Promise.all(contexts.map(context=>context.tracing.start({screenshots:true,snapshots:true,sources:true})));
      |                                                             ^ Error: tracing.start: Tracing has been already started
  86  |     for(const page of [a,b])page.on('pageerror',e=>errors.push(e.message));
  87  |     await boot(a);
  88  |     const welcomeEvidence=testInfo.outputPath('welcome-short-window-multiplayer.png');
  89  |     await a.screenshot({path:welcomeEvidence});await testInfo.attach('welcome-short-window-multiplayer',{path:welcomeEvidence,contentType:'image/png'});
  90  |     await join(a,'海风');const code=await a.evaluate(()=>window.__NEON__.snapshot().multiplayer.code);
  91  |     await a.locator('#multiplayer').click();
  92  |     await boot(b);await join(b,'榕荫',code);await a.locator('#resume').click();
  93  |     await expect.poll(()=>a.evaluate(()=>window.__NEON__.snapshot().multiplayer.players.length)).toBe(2);
  94  |     await expect.poll(()=>b.evaluate(()=>window.__NEON__.snapshot().multiplayer.meshes.filter(p=>p.visible).length)).toBe(1);
  95  |     const start=await a.evaluate(()=>window.__NEON__.snapshot().position);
  96  |     await a.locator('#game').focus();
  97  |     await holdUntil(a,'KeyW',({start})=>Math.hypot(window.__NEON__.snapshot().position.x-start.x,window.__NEON__.snapshot().position.z-start.z)>3,{start},evidence,'walk peer three metres');
  98  |     const target=await a.evaluate(()=>window.__NEON__.snapshot().position);
  99  |     await expect.poll(()=>b.evaluate(({target})=>{const mesh=window.__NEON__.snapshot().multiplayer.meshes[0];return mesh?Math.hypot(mesh.x-target.x,mesh.z-target.z):1000;},{target})).toBeLessThan(.6);
  100 |     await holdUntil(a,'KeyW',()=>{const s=window.__NEON__.snapshot();return s.cars.some(c=>c.id==='starter'&&Math.hypot(c.x-s.position.x,c.z-s.position.z)<5);},null,evidence,'approach starter car door');
  101 |     await a.keyboard.press('KeyE');await expect.poll(()=>a.evaluate(()=>window.__NEON__.snapshot().inCar)).toBe('starter');
  102 |     const carStart=await a.evaluate(()=>window.__NEON__.snapshot().position);
  103 |     await holdUntil(a,'KeyW',({carStart})=>Math.hypot(window.__NEON__.snapshot().position.x-carStart.x,window.__NEON__.snapshot().position.z-carStart.z)>3,{carStart},evidence,'drive shared starter car');
  104 |     await holdUntil(a,'Space',()=>window.__NEON__.snapshot().speed<.5,null,evidence,'brake shared starter car');
  105 |     const carTarget=await a.evaluate(()=>window.__NEON__.snapshot().cars.find(c=>c.id==='starter'));
  106 |     await expect.poll(()=>b.evaluate(({carTarget})=>{const car=window.__NEON__.snapshot().cars.find(c=>c.id==='starter');return Math.hypot(car.x-carTarget.x,car.z-carTarget.z);},{carTarget})).toBeLessThan(1);
  107 |     await a.keyboard.press('KeyE');await expect.poll(()=>a.evaluate(()=>window.__NEON__.snapshot().inCar)).toBe(null);
  108 |     await a.locator('#multiplayer').click();await a.locator('#room-message').fill('一起去看海');await a.locator('#room-chat-form button').click();
  109 |     await b.locator('#multiplayer').click();await expect(b.locator('#room-chat')).toContainText('海风：一起去看海');
  110 |     await a.locator('#room-leave').click();await expect.poll(()=>b.evaluate(()=>window.__NEON__.snapshot().multiplayer.players.length)).toBe(1);
  111 |     await expect.poll(()=>b.evaluate(()=>window.__NEON__.snapshot().multiplayer.meshes.length)).toBe(0);
  112 |     expect(errors).toEqual([]);failed=false;
  113 |   }finally{await finishClients(clients,contexts,testInfo,failed,evidence);}
  114 | });
  115 | 
  116 | 
  117 | test('two browsers synchronize expanded east-bay addresses and elevator floors beyond the former 320 metre limit', async ({ playwright }, testInfo) => {
  118 |   test.setTimeout(900000);
  119 |   const clients = await Promise.all([
  120 |     playwright.chromium.launch(testInfo.project.use.launchOptions),
  121 |     playwright.chromium.launch(testInfo.project.use.launchOptions),
  122 |   ]);
  123 |   const contexts = [], evidence = []; let failed = true;
  124 |   try {
  125 |     const options = { baseURL: testInfo.project.use.baseURL, viewport: { width: 640, height: 400 } };
  126 |     const first = await clients[0].newContext(options), second = await clients[1].newContext(options);
  127 |     contexts.push(first, second);
  128 |     await Promise.all(contexts.map(context => context.tracing.start({ screenshots: true, snapshots: true, sources: true })));
  129 |     const a = await first.newPage(), b = await second.newPage(), errors = [];
  130 |     for (const page of [a, b]) {
  131 |       page.on('pageerror', error => errors.push(error.message));
  132 |       page.on('response', response => {
  133 |         if (response.status() >= 400 && new URL(response.url()).pathname.startsWith('/api/'))
  134 |           errors.push(`HTTP ${response.status()}: ${new URL(response.url()).pathname}`);
  135 |       });
  136 |     }
  137 |     // Observe the second browser's actual server-sent events. This reads the
  138 |     // wire world identifier without changing the runtime or injecting poses.
  139 |     const network = await second.newCDPSession(b);
  140 |     await network.send('Network.enable');
  141 |     let received = null, trackedId = null;
  142 |     const receivedHeights = [];
  143 |     network.on('Network.eventSourceMessageReceived', event => {
  144 |       try {
  145 |         const packet = JSON.parse(event.data);
  146 |         if (Array.isArray(packet.players)) {
  147 |           received = packet;
  148 |           const visitor = packet.players.find(player => player.id === trackedId);
  149 |           if (visitor?.scene.startsWith('interior:east-012:')) receivedHeights.push(visitor.y);
  150 |         }
  151 |       }
  152 |       catch { errors.push('Invalid room event JSON'); }
  153 |     });
  154 |     await boot(a); await join(a, '东湾访客');
  155 |     const initial = await snapshot(a), code = initial.multiplayer.code, visitorId = initial.multiplayer.id;
  156 |     trackedId = visitorId;
  157 |     await a.locator('#multiplayer').click();
  158 |     await boot(b); await join(b, '海湾观察员', code);
  159 |     await b.locator('#multiplayer').click(); await a.locator('#resume').click();
  160 |     await expect.poll(() => received?.world).toBe('neon-harbor-v08');
  161 |     await expect.poll(() => received?.players.length).toBe(2);
  162 | 
  163 |     const assertRemotePose = async (position, scene) => {
  164 |       await expect.poll(() => {
  165 |         const peer = received?.players.find(player => player.id === visitorId);
  166 |         return peer?.scene === scene ? Math.hypot(peer.x - position.x, peer.y - position.y, peer.z - position.z) : Infinity;
  167 |       }).toBeLessThan(0.45);
  168 |       expect(received.world).toBe('neon-harbor-v08'); expect(received.code).toBe(code);
  169 |       await expect.poll(() => b.evaluate(({ visitorId, position, scene }) => {
  170 |         const peer = window.__NEON__.snapshot().multiplayer.players.find(player => player.id === visitorId);
  171 |         return peer?.scene === scene ? Math.hypot(peer.x - position.x, peer.y - position.y, peer.z - position.z) : Infinity;
  172 |       }, { visitorId, position, scene })).toBeLessThan(0.45);
  173 |       return received.players.find(player => player.id === visitorId);
  174 |     };
  175 |     const visit = async building => {
  176 |       await a.locator('#explore-city').click();
  177 |       await expect(a.locator('#atlas-results')).toBeVisible();
  178 |       await a.locator(`[data-visit-building="${building.id}"]`).click();
  179 |       await expect(a.locator('#panel')).not.toBeVisible({ timeout: 60000 });
  180 |       await expect(a.locator('#interaction')).toContainText(`进入 ${building.name}`);
  181 |       const state = await snapshot(a);
  182 |       expect(state.position.x).toBeCloseTo(building.entrance.x, 1);
  183 |       expect(state.position.z).toBeCloseTo(building.entrance.z, 1);
  184 |       await assertRemotePose(state.position, 'outdoor');
  185 |       return state;
```